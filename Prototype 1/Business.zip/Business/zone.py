from Enums.toggle import*
import time
import threading

class Zone:
    def __init__(self, sensorReader = None,
                lightWriter = None,
                controller = None,
                prevZone = None,
                nextZone = None):
        self.sensorReader = sensorReader
        self.lightWriter = lightWriter
        self.prevZone = prevZone
        self.nextZone = nextZone
        self.controller = controller


    # Returns true if the sensor sees a person in the zone
    def IsOccupied(self):
        return self.sensorReader.isOccupied()

    # Sets the light to ON or OFF
    def ToggleLight(self, value):
        self.lightWriter.setLight(value)

    def CheckIfActive(self): 
        while (not self.controller.inBed):
            
            if (not self.IsOccupied() and self.nextZone.IsOccupied()):
                self.ToggleLight(Toggle.OFF)
                self.nextZone.SetActive()
                break
            else:
                time.sleep(1)



    # Starts CheckIfActive as a thread
    def StartCheckIfActive(self):
        thread = threading.Thread(
            target = self.CheckIfActive,
            daemon = True
        )
        thread.start()

    # Function called when a zone becomes active
    def SetActive(self):
        self.ToggleLight(Toggle.ON)
        self.nextZone.ToggleLight(Toggle.ON)
        self.StartCheckIfActive()
    
    

